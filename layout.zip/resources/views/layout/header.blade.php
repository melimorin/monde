<header>
    <h1>@yield('titre')</h1>
</header>
